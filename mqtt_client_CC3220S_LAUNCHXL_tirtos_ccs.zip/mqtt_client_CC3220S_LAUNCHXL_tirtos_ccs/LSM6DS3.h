/*
 * LSM6DS3.h
 *
 *  Created on: 7 jun. 2021
 *      Author: Gebruiker
 */

#ifndef LSM6DS3_H_
#define LSM6DS3_H_

#include <stdint.h>

/* I2C slave addresses */
#define LSM6DS3_pedometer      0x6A

/* register addresses */
#define LSM6DS3_STEP_COUNTER_L          0x4B
#define LSM6DS3_STEP_COUNTER_H          0x4C
#define LSM6DS3_ACC_GYRO_CTRL1_XL       0x10
#define LSM6DS3_ACC_GYRO_CTRL10_C       0x19
#define LSM6DS3_ACC_GYRO_TAP_CFG1       0x58
#define LSM6DS3_ACC_GYRO_INT1_CTRL      0x0D


/* register variables */
#define LSM6DS3_ACC_GYRO_FS_XL_2G       0x00
#define LSM6DS3_ACC_GYRO_ODR_XL_26Hz    0x20
#define LSM6DS3_PEDO_RST_STEP           0x3E
#define LSM6DS3_PEDO_EN                 0x40
#define LSM6DS3_INT1_FIFO_OVR           0x10


int8_t cc3220_LSM6DS3_step_counter_init();
int8_t cc3220_LSM6DS3_step_counter_read(char *stappen);


#endif /* LSM6DS3_H_ */
