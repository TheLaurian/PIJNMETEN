/*
 * LSM6DS3.c
 *
 *  Created on: 7 jun. 2021
 *      Author: Gebruiker
 */
#include <stdint.h>
#include <stdio.h>


#include "LSM6DS3.h"
#include "pee50_i2c.h"

int8_t cc3220_LSM6DS3_step_counter_init()
{
    int8_t write_buffer = 0;

    cc3220_i2c_init();
    cc3220_i2c_open();

    write_buffer |= LSM6DS3_ACC_GYRO_FS_XL_2G;
    write_buffer |= LSM6DS3_ACC_GYRO_ODR_XL_26Hz;

    /* configure output data rate of 26Hz & full scale selection of 2g for accelerometer */
    if(cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_CTRL1_XL, write_buffer) < 0) {
        printf("write 1\n");
    }

    /* reset steps from step counter */
    write_buffer = LSM6DS3_PEDO_RST_STEP;
    if(cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_CTRL10_C, write_buffer) < 0 ) {
        printf("write 2\n");
    }

    /* pedometer enable */
    write_buffer = LSM6DS3_PEDO_EN;
    if(cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_TAP_CFG1, write_buffer) < 0 ) {
        printf("write 3\n");
    }

    /* interrupt pin assigned to step counter */
    write_buffer = LSM6DS3_INT1_FIFO_OVR;
    if(cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_INT1_CTRL, write_buffer) < 0) {
        printf("write 4\n");
    }

    cc3220_i2c_close();

    return 0;
}



int8_t cc3220_LSM6DS3_step_counter_read()
{
    uint8_t read_buffer = 0;
    uint16_t step_count = 0;

    cc3220_i2c_init();
    //printf("%d %d %d\n", i2c_params.transferMode, i2c_params.transferCallbackFxn,i2c_params.bitRate);
    cc3220_i2c_open();
    if(cc3220_i2c_read_8bit(LSM6DS3_pedometer, LSM6DS3_STEP_COUNTER_H, &read_buffer) < 0) {
        printf("read 1\n");
    }

    step_count = (read_buffer << 8) & 0xFFFF;

    if(cc3220_i2c_read_8bit(LSM6DS3_pedometer, LSM6DS3_STEP_COUNTER_L, &read_buffer) < 0) {
        printf("read 2\n");
    }

    step_count |= read_buffer;
    printf("Steps: %d \n", step_count);
    cc3220_i2c_close();
    return 0;
}
