/*
 * LSM6DS3.c
 *
 *  Created on: 7 jun. 2021
 *      Author: Gebruiker
 */
#include <stdint.h>

#include "LSM6DS3.h"
#include "stepcount_i2c.h"

int8_t cc3220_LSM6DS3_step_counter_init()
{
    int8_t write_buffer = 0;

    cc3220_i2c_init();
    cc3220_i2c_open();

    write_buffer |= LSM6DS3_ACC_GYRO_FS_XL_2G;
    write_buffer |= LSM6DS3_ACC_GYRO_ODR_XL_26Hz;

    /* configure output data rate of 26Hz & full scale selection of 2g for accelerometer */
    cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_CTRL1_XL, write_buffer);

    /* reset steps from step counter */
    write_buffer = LSM6DS3_PEDO_RST_STEP;
    cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_CTRL10_C, write_buffer);

    /* pedometer enable */
    write_buffer = LSM6DS3_PEDO_EN;
    cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_TAP_CFG1, write_buffer);

    /* interrupt pin assigned to step counter */
    write_buffer = LSM6DS3_INT1_FIFO_OVR;
    cc3220_i2c_write_8bit(LSM6DS3_pedometer, LSM6DS3_ACC_GYRO_INT1_CTRL, write_buffer);

    cc3220_i2c_close();

    return 0;
}


int8_t cc3220_LSM6DS3_step_counter_read(uint16_t *stappen)
{
    uint8_t read_buffer = 0;

    cc3220_i2c_init();
    cc3220_i2c_open();
    cc3220_i2c_read_8bit(LSM6DS3_pedometer, LSM6DS3_STEP_COUNTER_H, &read_buffer);

    *stappen = (read_buffer << 8) & 0xFFFF;

    cc3220_i2c_read_8bit(LSM6DS3_pedometer, LSM6DS3_STEP_COUNTER_L, &read_buffer);

    *stappen |= read_buffer;
    cc3220_i2c_close();
    return 0;
}
